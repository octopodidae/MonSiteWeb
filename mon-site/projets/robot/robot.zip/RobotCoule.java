class RobotCoule extends Exception {}
